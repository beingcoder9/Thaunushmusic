<?php

$conn = mysqli_connect('localhost','root','Thanush@123Naidu','thanush') or die('connection failed');

?>